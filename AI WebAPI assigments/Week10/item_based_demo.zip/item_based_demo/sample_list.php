<?php

$books =  array(
                
    "Brigette" => array("the god delusion" => 3.5, "the shack" => 4,"the birds in my life" => 2.5,"new moon" => 3.5),
    
    "Sonia" => array("the last lecture" => 2.5, "the god delusion" => 3.5, "the shack" => 3.5, "the birds in my life" => 2.5, "new moon" => 1),
    
    "Yutao" => array("the shack" => 5, "new moon" => 3.5),    
    "Navdeep" => array("the last lecture" => 2.5),
	
    "Jiuling" => array("the birds in my life" => 5, "new moon" => 3.5),
	
    "Liang" => array("the last lecture" => 3, "the god delusion" => 1.5,"the shack" => 3.5),
  );



?>